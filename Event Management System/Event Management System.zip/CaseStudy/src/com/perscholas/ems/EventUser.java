package com.perscholas.ems;

public class EventUser extends User {
	
	public EventUser()
	{
		super();
	}
	
	public EventUser(int id, String name, String username, String email, String password)
	{
		super(id, name, username, email, password);
	}
	
	// print out message about event user
	@Override
	public String toString()
	{
		return("EVENT USER: \n" + super.toString());
	}
}
