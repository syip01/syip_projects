package com.perscholas.ems;

import java.time.DateTimeException;
import java.time.LocalDateTime;

public class Event {
	protected static final int DEFAULT_ID = 0;
	private int id;
	private String groupName;
	private String roomName;
	private String location;
	private LocalDateTime startTime;
	private LocalDateTime endTime;
	
	public Event()
	{
		this(DEFAULT_ID, "Default Group Name", "Default Room Name", "Default Location");
	}
	
	public Event(int id, String groupName, String roomName, String location)
	{
		setId(id);
		this.groupName = groupName;
		this.roomName = roomName;
		this.location = location;
		startTime = null;
		endTime = null;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		if(id < DEFAULT_ID)
			throw new IllegalArgumentException("Invalid id");
		this.id = id;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getRoomName() {
		return roomName;
	}

	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public LocalDateTime getStartTime() {
		return startTime;
	}

	public void setStartTime(int year, int month, int day, int hour, int minute) {
		try
		{
			this.startTime = LocalDateTime.of(year, month, day, hour, minute);
		}
		catch (DateTimeException e)
		{
			System.out.println("Unable to set start time: Invalid date/time");
		}
	}

	public LocalDateTime getEndTime() {
		return endTime;
	}

	public void setEndTime(int year, int month, int day, int hour, int minute) {
		try
		{
			this.endTime = LocalDateTime.of(year, month, day, hour, minute);
		}
		catch (DateTimeException e)
		{
			System.out.println("Unable to set end time: Invalid date/time");
		}
	}
	
	public void setStartTime(LocalDateTime startTime) {
		this.startTime = startTime;
	}

	public void setEndTime(LocalDateTime endTime) {
		this.endTime = endTime;
	}

	// print out message about event
	@Override
	public String toString()
	{
		return("ID: " + id + "\tGroup Name: " + groupName + "\tRoom Name: " + roomName + "\tLocation: " + location
				+ "\nStart Time: " + (startTime != null ? startTime : "UNKNOWN")
				+ "\t End Time: " + (endTime != null ? endTime : "UNKNOWN"));
	}
}
