package com.perscholas.ems;

public abstract class User {
	protected static final int DEFAULT_ID = 0;
	protected int id;
	protected String name;
	protected String username;
	protected String email;
	protected String password;
	// using regex used for emails
	// https://emailregex.com/
	protected static final String EMAIL_REGEX = 
			"(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|\"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])";
	
	public User()
	{
		this(DEFAULT_ID, "Default User", "username", "user@gmail.com", "password");
	}
	
	public User(int id, String name, String username, String email, String password)
	{
		this.setId(id);
		this.name = name;
		this.username = username;
		this.setEmail(email);
		this.password = password;		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		if(id < DEFAULT_ID)
			throw new IllegalArgumentException("Invalid id: Must be greater than " + DEFAULT_ID);
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		if(!username.equals(""))
			this.username = username;
		else
			throw new IllegalArgumentException("Invalid username: empty string");
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		if (validateEmail(email))
			this.email = email;
		else
			throw new IllegalArgumentException("Invalid email");
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	// public helper function for email validation
	public static boolean validateEmail(String email)
	{
		return email.matches(EMAIL_REGEX);
	}
	
	// print out message about user
	@Override
	public String toString()
	{
		return("ID: " + id + "\t Name: " + name + "\t Username: " + username
				+ "\nEmail: " + email + "\tPassword: " + password + "\n");
	}
}
