package com.perscholas.ems;

public class EventAdmin extends User {
	
	public EventAdmin()
	{
		super();
	}
	
	public EventAdmin(int id, String name, String username, String email, String password)
	{
		super(id, name, username, email, password);
	}
	
	// print out message about event admin
	@Override
	public String toString()
	{
		return("EVENT ADMIN: \n" + super.toString());
	}
}
