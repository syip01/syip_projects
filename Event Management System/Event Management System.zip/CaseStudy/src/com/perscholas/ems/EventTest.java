package com.perscholas.ems;

import java.time.DateTimeException;
import java.time.LocalDateTime;
import java.util.Scanner;

public class EventTest {
	static final int MENU_ERROR = -1;
	static final int MENU_CREATE_USER = 1;
	static final int MENU_CREATE_ADMIN = 2;
	static final int MENU_CREATE_EVENT = 3;
	static final int MENU_DISPLAY_USER = 4;
	static final int MENU_DISPLAY_ADMIN = 5;
	static final int MENU_DISPLAY_EVENT = 6;
	static final int MENU_QUIT = 7;
	

	static Scanner console = new Scanner(System.in);
	static EventUser user = new EventUser();
	static EventAdmin admin = new EventAdmin();
	static Event event = new Event();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String input;
		int option;
		do
		{
			System.out.println(MENU_CREATE_USER + ") Create User");
			System.out.println(MENU_CREATE_ADMIN + ") Create Admin");
			System.out.println(MENU_CREATE_EVENT + ") Create Event");
			System.out.println(MENU_DISPLAY_USER + ") Display User");
			System.out.println(MENU_DISPLAY_ADMIN + ") Display Admin");
			System.out.println(MENU_DISPLAY_EVENT + ") Display Event");
			System.out.println(MENU_QUIT + ") Quit Program");
			System.out.print("Enter option: ");
			
			input = console.nextLine();
			
			try
			{
				option = Integer.parseInt(input);
			}
			catch(NumberFormatException e)
			{
				option = MENU_ERROR;
			}
			
			switch(option)
			{
			case MENU_CREATE_USER:
				createUser();
				break;
			case MENU_CREATE_ADMIN:
				createAdmin();
				break;
			case MENU_CREATE_EVENT:
				createEvent();
				break;
			case MENU_DISPLAY_USER:
				System.out.println(user);
				break;
			case MENU_DISPLAY_ADMIN:
				System.out.println(admin);
				break;
			case MENU_DISPLAY_EVENT:
				System.out.println(event);
				break;
			case MENU_QUIT:
				System.out.println("Quitting Program");
				break;
			case MENU_ERROR:
			default:
				System.out.println("Invalid Menu Input");
			}			
		} while (option != MENU_QUIT);

		console.close();
	}
	
	public static void createUser()
	{
		boolean validData = false;
		while(!validData)
		{
			try
			{
				user.setId(enterId());
				validData = true;
				// eat newline
				console.nextLine();
			}
			catch (IllegalArgumentException e)
			{
				System.out.println("Error: Invalid id");
			}
		}
		
		user.setName(enterName());
		
		validData = false;
		while(!validData)
		{
			try
			{
				user.setUsername(enterUsername());
				validData = true;
			}
			catch (IllegalArgumentException e)
			{
				System.out.println("Error: Empty username");
			}
		}
		
		validData = false;
		while(!validData)
		{
			try
			{
				user.setEmail(enterEmail());
				validData = true;
			}
			catch (IllegalArgumentException e)
			{
				System.out.println("Error: Invalid email address");
			}
		}
		
		user.setPassword(enterPassword());
	}
	
	public static void createAdmin()
	{
		boolean validData = false;
		while(!validData)
		{
			try
			{
				admin.setId(enterId());
				validData = true;
				// eat newline
				console.nextLine();
			}
			catch (IllegalArgumentException e)
			{
				System.out.println("Error: Invalid id");
			}
		}

		admin.setName(enterName());
		
		validData = false;
		while(!validData)
		{
			try
			{
				admin.setUsername(enterUsername());
				validData = true;
			}
			catch (IllegalArgumentException e)
			{
				System.out.println("Error: Empty username");
			}
		}
		
		validData = false;
		while(!validData)
		{
			try
			{
				admin.setEmail(enterEmail());
				validData = true;
			}
			catch (IllegalArgumentException e)
			{
				System.out.println("Error: Invalid email address");
			}
		}
		
		admin.setPassword(enterPassword());
	}
	
	public static int enterId()
	{
		System.out.print("Enter ID: ");
		return console.nextInt();
	}
	
	public static String enterName()
	{
		System.out.print("Enter name: ");
		return console.nextLine();
	}
	
	public static String enterUsername()
	{
		System.out.print("Enter username: ");
		return console.nextLine();
	}
	
	public static String enterEmail()
	{
		System.out.print("Enter email: ");
		return console.nextLine();
	}
	
	public static String enterPassword()
	{
		System.out.print("Enter password: ");
		return console.nextLine();
	}
		
	
	public static LocalDateTime enterTime()
	{
		LocalDateTime aTime = null;
		
		boolean validData = false;
		
		while(!validData)
		{
			System.out.print("Enter year: ");
			int year = console.nextInt();
			System.out.print("Enter month: ");
			int month = console.nextInt();
			System.out.print("Enter day: ");
			int day = console.nextInt();
			System.out.print("Enter hour: ");
			int hour = console.nextInt();
			System.out.print("Enter minute: ");
			int minute = console.nextInt();
			
			try
			{
				aTime = LocalDateTime.of(year, month, day, hour, minute);
				validData = true;
			}
			catch (DateTimeException e)
			{
				System.out.println("Invalid date/time");
			}						
		}
				
		return aTime;
	}
	
	public static void createEvent()
	{
		boolean validData = false;
		while(!validData)
		{
			try
			{
				event.setId(enterId());
				validData = true;
				// eat newline
				console.nextLine();
			}
			catch (IllegalArgumentException e)
			{
				System.out.println("Error: Invalid id");
			}
		}
		
		System.out.print("Enter group name: ");
		event.setGroupName(console.nextLine());
		
		System.out.print("Enter room name: ");
		event.setRoomName(console.nextLine());
		
		System.out.print("Enter location: ");
		event.setLocation(console.nextLine());
		
		System.out.println("Enter start time:");
		event.setStartTime(enterTime());
		System.out.println("Enter end time:");
		event.setEndTime(enterTime());
		
		// eat newline
		console.nextLine();
	}
}
