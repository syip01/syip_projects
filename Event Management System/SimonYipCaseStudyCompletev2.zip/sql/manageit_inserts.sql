-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.4.6-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             9.5.0.5196
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for ems
CREATE DATABASE IF NOT EXISTS `ems` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `ems`;

-- Dumping structure for table ems.emailinfo
CREATE TABLE IF NOT EXISTS `emailinfo` (
  `ID` int(11) NOT NULL,
  `EMAIL` varchar(255) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table ems.emailinfo: ~0 rows (approximately)
/*!40000 ALTER TABLE `emailinfo` DISABLE KEYS */;
/*!40000 ALTER TABLE `emailinfo` ENABLE KEYS */;

-- Dumping structure for table ems.event
CREATE TABLE IF NOT EXISTS `event` (
  `ID` int(11) NOT NULL,
  `ENDTIME` datetime NOT NULL,
  `STARTTIME` datetime NOT NULL,
  `STATUS` int(11) NOT NULL,
  `adminid` int(11) DEFAULT NULL,
  `groupid` int(11) NOT NULL,
  `roomid` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_EVENT_groupid` (`groupid`),
  KEY `FK_EVENT_adminid` (`adminid`),
  KEY `FK_EVENT_roomid` (`roomid`),
  CONSTRAINT `FK_EVENT_adminid` FOREIGN KEY (`adminid`) REFERENCES `user` (`ID`),
  CONSTRAINT `FK_EVENT_groupid` FOREIGN KEY (`groupid`) REFERENCES `group` (`ID`),
  CONSTRAINT `FK_EVENT_roomid` FOREIGN KEY (`roomid`) REFERENCES `room` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table ems.event: ~2 rows (approximately)
/*!40000 ALTER TABLE `event` DISABLE KEYS */;
INSERT INTO `event` (`ID`, `ENDTIME`, `STARTTIME`, `STATUS`, `adminid`, `groupid`, `roomid`) VALUES
	(1551, '2019-08-09 21:00:00', '2019-08-09 18:00:00', 3, 1, 251, 152),
	(1751, '2019-08-22 21:00:00', '2019-08-22 18:00:00', 0, 1, 301, 201);
/*!40000 ALTER TABLE `event` ENABLE KEYS */;

-- Dumping structure for table ems.group
CREATE TABLE IF NOT EXISTS `group` (
  `ID` int(11) NOT NULL,
  `EMAIL` varchar(255) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `NAME` (`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table ems.group: ~5 rows (approximately)
/*!40000 ALTER TABLE `group` DISABLE KEYS */;
INSERT INTO `group` (`ID`, `EMAIL`, `NAME`) VALUES
	(251, 'computerclub@gmail.com', 'Computer Club'),
	(301, 'chessclub@gmail.com', 'Chess Club'),
	(1901, 'artclub@gmail.com', 'Art Club'),
	(2401, 'foodclub@gmail.com', 'Food Club');
/*!40000 ALTER TABLE `group` ENABLE KEYS */;

-- Dumping structure for table ems.group_emailinfo
CREATE TABLE IF NOT EXISTS `group_emailinfo` (
  `Group_ID` int(11) NOT NULL,
  `mailingList_ID` int(11) NOT NULL,
  PRIMARY KEY (`Group_ID`,`mailingList_ID`),
  KEY `FK_Group_EMAILINFO_mailingList_ID` (`mailingList_ID`),
  CONSTRAINT `FK_Group_EMAILINFO_Group_ID` FOREIGN KEY (`Group_ID`) REFERENCES `group` (`ID`),
  CONSTRAINT `FK_Group_EMAILINFO_mailingList_ID` FOREIGN KEY (`mailingList_ID`) REFERENCES `emailinfo` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table ems.group_emailinfo: ~0 rows (approximately)
/*!40000 ALTER TABLE `group_emailinfo` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_emailinfo` ENABLE KEYS */;

-- Dumping structure for table ems.room
CREATE TABLE IF NOT EXISTS `room` (
  `ID` int(11) NOT NULL,
  `LOCATION` varchar(255) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `NAME` (`NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table ems.room: ~4 rows (approximately)
/*!40000 ALTER TABLE `room` DISABLE KEYS */;
INSERT INTO `room` (`ID`, `LOCATION`, `NAME`) VALUES
	(152, 'Saville Hall - Engineering Room', 'S100'),
	(201, 'President\'s Place - Computer Lab', 'PP414'),
	(2351, 'President\'s Place - Computer Lab', 'PP411');
/*!40000 ALTER TABLE `room` ENABLE KEYS */;

-- Dumping structure for table ems.sequence
CREATE TABLE IF NOT EXISTS `sequence` (
  `SEQ_NAME` varchar(50) NOT NULL,
  `SEQ_COUNT` decimal(38,0) DEFAULT NULL,
  PRIMARY KEY (`SEQ_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table ems.sequence: ~0 rows (approximately)
/*!40000 ALTER TABLE `sequence` DISABLE KEYS */;
INSERT INTO `sequence` (`SEQ_NAME`, `SEQ_COUNT`) VALUES
	('SEQ_GEN', 2650);
/*!40000 ALTER TABLE `sequence` ENABLE KEYS */;

-- Dumping structure for table ems.user
CREATE TABLE IF NOT EXISTS `user` (
  `ID` int(11) NOT NULL,
  `role` varchar(31) DEFAULT NULL,
  `EMAIL` varchar(255) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `PASSWORD` varchar(255) NOT NULL,
  `USERNAME` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `USERNAME` (`USERNAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table ems.user: ~4 rows (approximately)
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`ID`, `role`, `EMAIL`, `NAME`, `PASSWORD`, `USERNAME`) VALUES
	(1, 'Admin', 'admin1@gmail.com', 'admin1', 'admin', 'admin'),
	(51, 'User', 'lala@gmail.com', 'lalala', 'lala', 'lala'),
	(1701, 'User', 'lala2@gmail.com', 'lala2', 'lala2', 'lala2'),
	(1801, 'User', 'lala3@gmail.com', 'lala3', 'lala3', 'lala3'),
	(1851, 'Admin', 'admin2@gmail.com', 'admin22', 'admin2', 'admin2'),
	(1951, 'User', 'lala555@email.com', 'lala55555', 'lala5', 'lala5'),
	(2001, 'Admin', 'admin4444@gmail.com', 'admin4444', 'admin4', 'admin4'),
	(2601, 'User', 'lala44@gmail.com', 'lala4444', 'lala4', 'lala4');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;

-- Dumping structure for table ems.users_groups
CREATE TABLE IF NOT EXISTS `users_groups` (
  `userid` int(11) NOT NULL,
  `groupid` int(11) NOT NULL,
  PRIMARY KEY (`userid`,`groupid`),
  KEY `FK_users_groups_groupid` (`groupid`),
  CONSTRAINT `FK_users_groups_groupid` FOREIGN KEY (`groupid`) REFERENCES `group` (`ID`),
  CONSTRAINT `FK_users_groups_userid` FOREIGN KEY (`userid`) REFERENCES `user` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table ems.users_groups: ~4 rows (approximately)
/*!40000 ALTER TABLE `users_groups` DISABLE KEYS */;
INSERT INTO `users_groups` (`userid`, `groupid`) VALUES
	(51, 251),
	(1701, 301),
	(1801, 251),
	(1801, 301);
/*!40000 ALTER TABLE `users_groups` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
