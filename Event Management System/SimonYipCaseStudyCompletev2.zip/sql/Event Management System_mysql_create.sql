CREATE TABLE `Rooms` (
	`id` INT NOT NULL AUTO_INCREMENT,
	`name` varchar(255) NOT NULL UNIQUE,
	`location` varchar(255) NOT NULL,
	PRIMARY KEY (`id`)
);

CREATE TABLE `Groups` (
	`id` INT NOT NULL AUTO_INCREMENT,
	`name` varchar(255) NOT NULL UNIQUE,
	`email` varchar(255) NOT NULL,
	PRIMARY KEY (`id`)
);

CREATE TABLE `EmailList` (
	`id` INT NOT NULL,
	`name` varchar(255) NOT NULL,
	`email` varchar(255) NOT NULL,
	PRIMARY KEY (`id`)
);

CREATE TABLE `Group_Email` (
	`groupid` INT NOT NULL AUTO_INCREMENT,
	`emailid` INT NOT NULL AUTO_INCREMENT,
	PRIMARY KEY (`groupid`,`emailid`)
);

CREATE TABLE `Events` (
	`id` INT NOT NULL AUTO_INCREMENT,
	`groupid` INT NOT NULL AUTO_INCREMENT,
	`roomid` INT NOT NULL,
	`adminid` INT,
	`starttime` DATETIME NOT NULL,
	`endtime` DATETIME NOT NULL,
	`status` INT NOT NULL,
	PRIMARY KEY (`id`)
);

CREATE TABLE `Users` (
	`id` INT NOT NULL AUTO_INCREMENT,
	`username` varchar(255) NOT NULL UNIQUE,
	`password` varchar(255) NOT NULL,
	`name` varchar(255) NOT NULL,
	`email` varchar(255) NOT NULL,
	`role` varchar(255) NOT NULL,
	PRIMARY KEY (`id`)
);

CREATE TABLE `Users_Groups` (
	`userid` INT NOT NULL,
	`groupid` INT NOT NULL AUTO_INCREMENT,
	PRIMARY KEY (`userid`,`groupid`)
);

ALTER TABLE `Group_Email` ADD CONSTRAINT `Group_Email_fk0` FOREIGN KEY (`groupid`) REFERENCES `Groups`(`id`);

ALTER TABLE `Group_Email` ADD CONSTRAINT `Group_Email_fk1` FOREIGN KEY (`emailid`) REFERENCES `EmailList`(`id`);

ALTER TABLE `Events` ADD CONSTRAINT `Events_fk0` FOREIGN KEY (`groupid`) REFERENCES `Groups`(`id`);

ALTER TABLE `Events` ADD CONSTRAINT `Events_fk1` FOREIGN KEY (`roomid`) REFERENCES `Rooms`(`id`);

ALTER TABLE `Events` ADD CONSTRAINT `Events_fk2` FOREIGN KEY (`adminid`) REFERENCES `Users`(`id`);

ALTER TABLE `Users_Groups` ADD CONSTRAINT `Users_Groups_fk0` FOREIGN KEY (`userid`) REFERENCES `Users`(`id`);

ALTER TABLE `Users_Groups` ADD CONSTRAINT `Users_Groups_fk1` FOREIGN KEY (`groupid`) REFERENCES `Groups`(`id`);

